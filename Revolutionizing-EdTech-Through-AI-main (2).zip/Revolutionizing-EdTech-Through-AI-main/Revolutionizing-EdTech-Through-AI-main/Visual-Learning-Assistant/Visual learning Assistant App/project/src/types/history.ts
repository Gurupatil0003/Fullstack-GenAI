export interface QuestionHistory {
  id: string;
  question: string;
  timestamp: number;
  solution?: string;
}