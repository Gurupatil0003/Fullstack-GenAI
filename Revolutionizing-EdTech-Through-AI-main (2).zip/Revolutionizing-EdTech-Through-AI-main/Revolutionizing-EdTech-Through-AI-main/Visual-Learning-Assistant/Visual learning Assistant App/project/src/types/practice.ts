export interface PracticeProblem {
  id: string;
  question: string;
  answer: string;
  explanation: string;
}