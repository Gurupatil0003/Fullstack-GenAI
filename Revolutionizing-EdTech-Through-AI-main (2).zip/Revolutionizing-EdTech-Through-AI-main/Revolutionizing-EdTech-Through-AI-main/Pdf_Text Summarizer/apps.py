import streamlit as st
import PyPDF2
import google.generativeai as genai
from docx import Document
import spacy

# Configure Google Gemini API
genai.configure(api_key="YOUR_API_KEY")

# Load English NLP model for keyword extraction
nlp = spacy.load("en_core_web_sm")

def extract_text_from_pdf(pdf_file):
    """Extract text from a PDF file."""
    pdf_reader = PyPDF2.PdfReader(pdf_file)
    text = "\n".join([page.extract_text() for page in pdf_reader.pages if page.extract_text()])
    return text

def extract_keywords(text, num_keywords=5):
    """Extracts key terms from the given text using spaCy."""
    doc = nlp(text)
    keywords = [token.text for token in doc if token.is_alpha and not token.is_stop]
    return list(set(keywords[:num_keywords]))

def generate_summary(text, summary_length, summary_format, language):
    """Generates an extractive summary using Google Gemini API."""
    prompt = (f"Extract key sentences from the given text and summarize it in {summary_length} length. "
              f"Format the summary as {summary_format}. Provide output in {language}.\n\n" + text)
    try:
        model = genai.GenerativeModel("gemini-1.5-flash")
        
        # Generate content using the model
        response = model.generate_content(prompt)
        
        # Extract the text from the response
        return response.text
    except Exception as e:
        return f"An error occurred: {e}"
    
def highlight_key_sentences(summary, keywords):
    """Highlights key sentences in the summary containing important keywords."""
    for keyword in keywords:
        summary = summary.replace(keyword, f"**{keyword}**")
    return summary

def save_summary(summary, file_format):
    """Saves the summary as a .txt or .docx file."""
    if file_format == "txt":
        with open("summary.txt", "w", encoding="utf-8") as file:
            file.write(summary)
        return "summary.txt"
    elif file_format == "docx":
        doc = Document()
        doc.add_paragraph(summary)
        file_path = "summary.docx"
        doc.save(file_path)
        return file_path
    
# Streamlit UI
st.title("PDF Summarizer with Google Gemini API")
st.sidebar.header("Settings")

# File uploader
uploaded_file = st.file_uploader("Upload a PDF", type=["pdf"])

# Summary format selection
summary_format = st.sidebar.radio("Select Summary Format", ["Plain Text", "Bullet Points", "Structured Sections"])

# Summary length selection
summary_length = st.sidebar.selectbox("Select Summary Length", ["Short", "Medium", "Long"])

# Language selection
language = st.sidebar.selectbox("Select Language", ["English", "Hindi", "Tamil", "Telugu", "Bengali", "Marathi", "Gujarati"])

if uploaded_file:
    text = extract_text_from_pdf(uploaded_file)
    st.subheader("Extracted Text")
    st.text_area("Extracted Text", text, height=200)

    # Keyword extraction
    keywords = extract_keywords(text)
    st.subheader("Extracted Keywords")
    st.write(", ".join(keywords))

    # Generate summary
    if st.button("Generate Summary"):
        # Add a loading state
        with st.spinner("Generating summary..."):
            summary = generate_summary(text, summary_length, summary_format, language)
            highlighted_summary = highlight_key_sentences(summary, keywords)
            
            st.subheader("Generated Summary")
            st.markdown(highlighted_summary)
            
            # Download options
            file_format = st.radio("Download format", ["txt", "docx"])
            file_path = save_summary(summary, file_format)
            st.download_button(label="Download Summary", data=open(file_path, "rb"), file_name=file_path)

st.write("\n\n *Built with Streamlit & Google Gemini API*")