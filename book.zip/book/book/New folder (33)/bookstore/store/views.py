from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib import messages
from .models import Book


# HOME PAGE — using dummy static book list
def home(request):
    books = [
        {'id': 1, 'title': 'The Midnight Library', 'price': 499, 'image': 'https://m.media-amazon.com/images/I/81eA+LfVz5L._SL1500_.jpg'},
        {'id': 2, 'title': 'Ikigai', 'price': 299, 'image': 'https://m.media-amazon.com/images/I/91bYsX41DVL._SL1500_.jpg'},
        {'id': 3, 'title': 'Rich Dad Poor Dad', 'price': 399, 'image': 'https://m.media-amazon.com/images/I/81bsw6fnUiL._SL1500_.jpg'},
        {'id': 4, 'title': 'Deep Work', 'price': 429, 'image': 'https://m.media-amazon.com/images/I/61H0K8C4vZL._SL1500_.jpg'},
        {'id': 5, 'title': 'The Psychology of Money', 'price': 349, 'image': 'https://m.media-amazon.com/images/I/71g2ednj0JL._SL1500_.jpg'},
        {'id': 6, 'title': 'Atomic Habits', 'price': 450, 'image': 'https://m.media-amazon.com/images/I/91bYsX41DVL._SL1500_.jpg'},
    ]
    return render(request, 'store/home.html', {'books': books})


# STATIC PAGES
def categories(request):
    return render(request, 'store/categories.html')

def contact(request):
    return render(request, 'store/contact.html')

def cart(request):
    return render(request, 'store/cart.html')


# AUTH
def register_view(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Registration successful. Please login.")
            return redirect('login')
        else:
            messages.error(request, "Invalid registration details")
    else:
        form = UserCreationForm()
    return render(request, 'store/register.html', {'form': form})


def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('home')
        else:
            messages.error(request, "Invalid credentials")
    else:
        form = AuthenticationForm()
    return render(request, 'store/login.html', {'form': form})


def logout_view(request):
    logout(request)
    return redirect('home')


# BUY & PAYMENT
@login_required
def buy(request, book_id):
    book = get_object_or_404(Book, id=book_id)
    if request.method == 'POST':
        quantity = int(request.POST.get('quantity', 1))
        # 👇 Corrected redirect with query params
        return redirect(f'/payment/?book_id={book_id}&quantity={quantity}')
    return render(request, 'store/buy.html', {'book': book})


@login_required
def payment(request):
    book_id = request.GET.get('book_id')
    quantity = int(request.GET.get('quantity', 1))

    book = get_object_or_404(Book, id=book_id)
    total_price = book.price * quantity

    return render(request, 'store/payment.html', {
        'book': book,
        'quantity': quantity,
        'total_price': total_price
    })


@login_required
def payment_success(request):
    if request.method == 'POST':
        book_title = request.POST.get('book_title')
        method = request.POST.get('method')
        return render(request, 'store/payment_success.html', {
            'book_title': book_title,
            'method': method
        })
    return redirect('home')
